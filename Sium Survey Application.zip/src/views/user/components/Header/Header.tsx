import Nav from "./Nav/Nav"

function Header() {
  return (<><Nav/></>)
}

export default Header
