
function EnveritasHeader() {

    return (
        <h2 className="font-mono text-4xl">
         Enveritas
        </h2>
    )
}

export default EnveritasHeader
